package application.gdms.com.poc_themehandling;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.StyleRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class ThemeActivity extends AppCompatActivity {

    public static final String INDIGO = "indigo";
    public static final String PINK = "pink";
    private static final String NIGHT_MODE = "night_mode";

    /*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(getSavedTheme());
        setContentView(R.layout.activity_theme);

       TextView themeName = findViewById(R.id.testTextViewTheme);
        themeName.setText(getSavedTheme() == R.style.AppTheme_NoActionBar_Indigo ? "Indigo" : "Pink");

        Button btnGreen = findViewById(R.id.btnGreen);
        btnGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTheme(INDIGO);
            }
        });

        Button btnBlue = findViewById(R.id.btnBlue);
        btnBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTheme(PINK);
            }
        });

        SwitchCompat switchCompat = findViewById(R.id.switchView);
        switchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    saveTheme(INDIGO);
                } else {
                    saveTheme(PINK);
                }
            }
        });

    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // init shared preferences
        if (isNightModeEnabled()) {
            setAppTheme(R.style.AppTheme_Base_Night);
        } else {
            setAppTheme(R.style.AppTheme_Base_Light);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



    }


    private void saveTheme(String value) {
        SharedPreferences.Editor editor = getPreferences(Activity.MODE_PRIVATE).edit();
        editor.putString("theme", value);
        editor.commit();
        recreate();

    }

    private int getSavedTheme() {
        String theme = getPreferences(Activity.MODE_PRIVATE).getString("theme", INDIGO);
        switch (theme) {
            case PINK:
                return R.style.AppTheme_NoActionBar_Pink;
            case INDIGO:
            default:
                return R.style.AppTheme_NoActionBar_Indigo;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        // Inflate switch
        Switch mSwitchNightMode = (Switch) menu.findItem(R.id.action_night_mode)
                .getActionView().findViewById(R.id.item_switch);

        // Get state from preferences
        if (isNightModeEnabled()) {
            mSwitchNightMode.setChecked(true);
        } else {
            mSwitchNightMode.setChecked(false);
        }

        mSwitchNightMode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (isNightModeEnabled()) {
                    setIsNightModeEnabled(false);
                    setAppTheme(R.style.AppTheme_Base_Light);
                } else {
                    setIsNightModeEnabled(true);
                    setAppTheme(R.style.AppTheme_Base_Night);
                }

                // Recreate activity
                recreate();
            }
        });

        return true;
    }
    private void setAppTheme(@StyleRes int style) {
        setTheme(style);
    }

    private boolean isNightModeEnabled() {
        SharedPreferences mSharedPref = getPreferences(Context.MODE_PRIVATE);
        return  mSharedPref.getBoolean(NIGHT_MODE, false);
    }

    private void setIsNightModeEnabled(boolean state) {
        SharedPreferences mSharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor mEditor = mSharedPref.edit();
        mEditor.putBoolean(NIGHT_MODE, state);
        mEditor.apply();
    }
}
